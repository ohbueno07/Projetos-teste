package br.com.samsung.samsungevaluationapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamsungEvaluationApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamsungEvaluationApiApplication.class, args);
	}

}
