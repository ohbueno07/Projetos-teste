package br.com.samsung.samsungevaluationapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamsungEvaluationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
